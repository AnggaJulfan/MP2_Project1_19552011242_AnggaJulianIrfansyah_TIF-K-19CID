# BMI Calculator 19552011242

![Screenshot](https://res.cloudinary.com/nitishk72/image/upload/v1595680512/nstack_in/blog/flutter/flutter-bmi-calculator.png)

I started a YouTube series where I will make complete app in one video.

> If you like our content then consider subscribing, It really motivates us.

## Article

There is complete write of the app you can find that on our [blog nstack.in](https://www.nstack.in/blog/flutter-bmi-calculator-app/).

https://www.nstack.in/blog/flutter-bmi-calculator-app/

## YouTube

There is video available at youtbe and here is the direct link

https://www.youtube.com/watch?v=T3dNQiPU8Jo

## For Contributors

If you would like to improve this and contribute then you are welcome. But please make a different brach before making any new change

I want to keep the original and improved version both.

## Credit

The app was originally created by the `Sptadeepa Ghosh`, All the UI is done by her. I only fixed the bug and after that made the made video. She don't use github so it's I uploaded on mine and shared with all.

# Thanks for coming here
# Repository-Baru
# BMICalculator_19552011242_AnggaJulianIrfansyah_19552011242
# BMICalculator_19552011242_AnggaJulianIrfansyah_19552011242
# BMICalculator_19552011242_AnggaJulianIrfansyah_19552011242
# BMICalculator_19552011242_AnggaJulianIrfansyah_19552011242
# BMICalculator_19552011242_AnggaJulianIrfansyah_19552011242
# BMICalculator_19552011242_AnggaJulianIrfansyah_19552011242
